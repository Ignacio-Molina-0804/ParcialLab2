import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ArrayList<String> adnSecuencia = new ArrayList<>();

        IngresoDeADN IngresoDeADN = new IngresoDeADN(scanner, adnSecuencia);
        allCombinations allCombinations = new allCombinations(adnSecuencia);
        confirmacionMutante confirmacionMutante = new confirmacionMutante(adnSecuencia);

        // DATOS INGRESADOS

        IngresoDeADN.procesarSecuenciaADN();

        // DATOS INGRESADOS

        // SEPARADOR DE DATOS Y COMPROBADOR DE IGUALDAD DE ADN

        ArrayList<String> combinaciones = allCombinations.combinationsFourLines(adnSecuencia);
        int numeroDeConfirmaciones = confirmacionMutante.confirmacionDeADNS(combinaciones);

        // SEPARADOR DE DATOS Y COMPROBADOR DE IGUALDAD DE ADN

        // MUESTRA LA SECUENCIA DE ADN INGRESADA

        System.out.println("--------------");
        System.out.println("Secuencia de ADN ingresada:");
        System.out.println("--------------");

        for (String sequence : adnSecuencia) {
            System.out.println(sequence);
        }

        // MUESTRA LA SECUENCIA DE ADN INGRESADA

        System.out.println("--------------");

        // PROGRAMA QUE COMPRUEBA SI ES MUTANTE

        esMutante esMutante = new esMutante(numeroDeConfirmaciones);
        boolean isMutant = esMutante.isMutant(numeroDeConfirmaciones);

        if (isMutant == true){

            System.out.println("Usted es mutante");

        } else {

            System.out.println("Usted no es mutante");

        }

        // PROGRAMA QUE COMPRUEBA SI ES MUTANTE

        /* CASO DE PRUEBA TRUE */
        /*

        // DATOS INGRESADOS

        ArrayList<String> adnSecuenciaPruebaTrue = new ArrayList<>();

        adnSecuenciaPruebaTrue.add("ATGCAT");
        adnSecuenciaPruebaTrue.add("ACCGCT");
        adnSecuenciaPruebaTrue.add("ACGCAT");
        adnSecuenciaPruebaTrue.add("ATGCAG");
        adnSecuenciaPruebaTrue.add("ATTGGA");
        adnSecuenciaPruebaTrue.add("ATGCAT");

        // DATOS INGRESADOS

        // SEPARADOR DE DATOS Y COMPROBADOR DE IGUALDAD DE ADN

        ArrayList<String> combinaciones = allCombinations.combinationsFourLines(adnSecuenciaPruebaTrue);
        int numeroDeConfirmaciones = confirmacionMutante.confirmacionDeADNS(combinaciones);

        // SEPARADOR DE DATOS Y COMPROBADOR DE IGUALDAD DE ADN

        // MUESTRA LA SECUENCIA DE ADN INGRESADA

        System.out.println("--------------");
        System.out.println("Secuencia de ADN ingresada:");
        System.out.println("--------------");

        for (String sequence : adnSecuenciaPruebaTrue) {
            System.out.println(sequence);
        }

        // MUESTRA LA SECUENCIA DE ADN INGRESADA

        System.out.println("--------------");

        // PROGRAMA QUE COMPRUEBA SI ES MUTANTE

        esMutante esMutante = new esMutante(numeroDeConfirmaciones);
        boolean isMutant = esMutante.isMutant(numeroDeConfirmaciones);

        if (isMutant == true){

            System.out.println("Usted es mutante");

        } else {

            System.out.println("Usted no es mutante");

        }

        // PROGRAMA QUE COMPRUEBA SI ES MUTANTE

        */
        /* CASO DE PRUEBA TRUE */



        /* CASO DE PRUEBA FALSE */
        /*

        // DATOS INGRESADOS

        ArrayList<String> adnSecuenciaPruebaFalse = new ArrayList<>();

        adnSecuenciaPruebaFalse.add("ATATAT");
        adnSecuenciaPruebaFalse.add("AATTAA");
        adnSecuenciaPruebaFalse.add("TATATA");
        adnSecuenciaPruebaFalse.add("ATATAT");
        adnSecuenciaPruebaFalse.add("AATTAA");
        adnSecuenciaPruebaFalse.add("TATATA");

        // DATOS INGRESADOS

        // SEPARADOR DE DATOS Y COMPROBADOR DE IGUALDAD DE ADN

        ArrayList<String> combinaciones = allCombinations.combinationsFourLines(adnSecuenciaPruebaFalse);
        int numeroDeConfirmaciones = confirmacionMutante.confirmacionDeADNS(combinaciones);

        // SEPARADOR DE DATOS Y COMPROBADOR DE IGUALDAD DE ADN

        // MUESTRA LA SECUENCIA DE ADN INGRESADA

        System.out.println("--------------");
        System.out.println("Secuencia de ADN ingresada:");
        System.out.println("--------------");

        for (String sequence : adnSecuenciaPruebaFalse) {
            System.out.println(sequence);
        }

        // MUESTRA LA SECUENCIA DE ADN INGRESADA

        System.out.println("--------------");

        // PROGRAMA QUE COMPRUEBA SI ES MUTANTE

        esMutante esMutante = new esMutante(numeroDeConfirmaciones);
        boolean isMutant = esMutante.isMutant(numeroDeConfirmaciones);

        if (isMutant == true){

            System.out.println("Usted es mutante");

        } else {

            System.out.println("Usted no es mutante");

        }

        // PROGRAMA QUE COMPRUEBA SI ES MUTANTE

        */
        /* CASO DE PRUEBA FALSE */

    }
}

