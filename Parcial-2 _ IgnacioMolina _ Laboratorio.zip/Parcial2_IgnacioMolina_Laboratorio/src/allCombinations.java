import java.util.ArrayList;

public class allCombinations {

    private ArrayList<String> adnSecuencia;

    public allCombinations(ArrayList<String> adnSecuencia) {
        this.adnSecuencia = adnSecuencia;
    }

    public allCombinations() {
    }

    public ArrayList<String> getAdnSecuencia() {
        return adnSecuencia;
    }

    public void setAdnSecuencia(ArrayList<String> adnSecuencia) {
        this.adnSecuencia = adnSecuencia;
    }

    static ArrayList<String> separateWordsFourLines(String finalADNGet) {
        ArrayList<String> separatedADNS = new ArrayList<>();

        for (int i = 0; i < finalADNGet.length(); i += 4) {
            String ADNS = finalADNGet.substring(i, Math.min(i + 4, finalADNGet.length()));
            separatedADNS.add(ADNS);
        }

        return separatedADNS;
    }

    static ArrayList<String> combinationsFourLines(ArrayList<String> ADNSecuence) {
        ArrayList<String> allCombinationsFourADN = new ArrayList<>();

        /* VERTICALES */

        for (int j = 5; j >= 0; j--) {
            for (int i = 0; i < 4; i++) {
                String ADN = ADNSecuence.get(i);
                char ADNSeparated = ADN.charAt(j);
                allCombinationsFourADN.add(String.valueOf(ADNSeparated));
            }
        }

        for (int j = 5; j >= 0; j--) {
            for (int i = 0; i < 4; i++) {
                String ADN = ADNSecuence.get(i + 1);
                char ADNSeparated = ADN.charAt(j);
                allCombinationsFourADN.add(String.valueOf(ADNSeparated));
            }
        }

        for (int j = 5; j >= 0; j--) {
            for (int i = 0; i < 4; i++) {
                String ADN = ADNSecuence.get(i + 2);
                char ADNSeparated = ADN.charAt(j);
                allCombinationsFourADN.add(String.valueOf(ADNSeparated));
            }
        }

        /* VERTICALES */

        /* DIAGONALES */

        for (int i = 5; i > 1; i--) {
            String ADN = ADNSecuence.get(i);
            char ADNSeparated = ADN.charAt(5 - i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 4; i > 0; i--) {
            String ADN = ADNSecuence.get(i);
            char ADNSeparated = ADN.charAt(5 - i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 5; i > 1; i--) {
            String ADN = ADNSecuence.get(5 - i);
            char ADNSeparated = ADN.charAt(i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 0; i < 4; i++) {
            String ADN = ADNSecuence.get(i);
            char ADNSeparated = ADN.charAt(i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 1; i < 5; i++) {
            String ADN = ADNSecuence.get(i);
            char ADNSeparated = ADN.charAt(i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 5; i > 1; i--) {
            String ADN = ADNSecuence.get(i);
            char ADNSeparated = ADN.charAt(i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 4; i > 0; i--) {
            String ADN = ADNSecuence.get(i);
            char ADNSeparated = ADN.charAt(4 - i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 4; i > 0; i--) {
            String ADN = ADNSecuence.get(4 - i);
            char ADNSeparated = ADN.charAt(i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        String ADNline1 = ADNSecuence.get(1);
        String ADNline2 = ADNSecuence.get(2);
        String ADNline3 = ADNSecuence.get(3);
        String ADNline4 = ADNSecuence.get(4);

        String ADNSeparated1 = String.valueOf(ADNline1.charAt(5)) +
                String.valueOf(ADNline2.charAt(4)) +
                String.valueOf(ADNline3.charAt(3)) +
                String.valueOf(ADNline4.charAt(2));

        allCombinationsFourADN.add(ADNSeparated1);

        String ADNline2_2 = ADNSecuence.get(2);
        String ADNline3_2 = ADNSecuence.get(3);
        String ADNline4_2 = ADNSecuence.get(4);
        String ADNline5 = ADNSecuence.get(5);

        String ADNSeparated2 = String.valueOf(ADNline5.charAt(1)) +
                String.valueOf(ADNline4_2.charAt(2)) +
                String.valueOf(ADNline3_2.charAt(3)) +
                String.valueOf(ADNline2_2.charAt(4));

        allCombinationsFourADN.add(ADNSeparated2);

        for (int i = 0; i < 4; i++) {
            String ADN = ADNSecuence.get(i);
            char ADNSeparated = ADN.charAt(i+1);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 0; i < 4; i++) {
            String ADN = ADNSecuence.get(i+1);
            char ADNSeparated = ADN.charAt(i+2);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 0; i < 4; i++) {
            String ADN = ADNSecuence.get(i+1);
            char ADNSeparated = ADN.charAt(i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 0; i < 4; i++) {
            String ADN = ADNSecuence.get(i+2);
            char ADNSeparated = ADN.charAt(i+1);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 0; i < 4; i++) {
            String ADN = ADNSecuence.get(i+2);
            char ADNSeparated = ADN.charAt(i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 0; i < 4; i++) {
            String ADN = ADNSecuence.get(i);
            char ADNSeparated = ADN.charAt(i+2);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }

        for (int i = 3; i >= 0; i--) {
            String ADN = ADNSecuence.get(i);
            char ADNSeparated = ADN.charAt(3 - i);
            allCombinationsFourADN.add(String.valueOf(ADNSeparated));
        }


        /* DIAGONALES */

        /* HORIZONTALES */

        for (int j = 5; j >= 0; j--) {
            for (int i = 0; i < 4; i++) {
                String ADN = ADNSecuence.get(j);
                char ADNSeparated = ADN.charAt(i);
                allCombinationsFourADN.add(String.valueOf(ADNSeparated));
            }
        }

        for (int j = 5; j >= 0; j--) {
            for (int i = 0; i < 4; i++) {
                String ADN = ADNSecuence.get(j);
                char ADNSeparated = ADN.charAt(i + 1);
                allCombinationsFourADN.add(String.valueOf(ADNSeparated));
            }
        }

        for (int j = 5; j >= 0; j--) {
            for (int i = 0; i < 4; i++) {
                String ADN = ADNSecuence.get(j);
                char ADNSeparated = ADN.charAt(i + 2);
                allCombinationsFourADN.add(String.valueOf(ADNSeparated));
            }
        }

        /* HORIZONTALES */



        String finalADNGet = String.join("", allCombinationsFourADN);

        ArrayList<String> separatedADNS = separateWordsFourLines(finalADNGet);

        return separatedADNS;
    }
}


