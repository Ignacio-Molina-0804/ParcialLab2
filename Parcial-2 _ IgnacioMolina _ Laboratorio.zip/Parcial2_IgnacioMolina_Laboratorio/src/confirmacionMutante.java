import java.util.ArrayList;

public class confirmacionMutante {

    private ArrayList<String> combinaciones;

    public confirmacionMutante(ArrayList<String> combinaciones) {
        this.combinaciones = combinaciones;
    }

    public confirmacionMutante() {
    }

    public ArrayList<String> getcombinaciones() {
        return combinaciones;
    }

    public void setcombinaciones(ArrayList<String> combinaciones) {
        this.combinaciones = combinaciones;
    }

    public int confirmacionDeADNS(ArrayList<String> combinaciones){

        String[] mutantADNFourLines = {"AAAA","GGGG","CCCC","TTTT"};

        int numeroDeCoincidencias = 0;
        int n = combinaciones.size();

        for (int i = 0; i < 4; i++) {

            for (int j = 0; j < n; j++) {

                if (combinaciones.get(j).equals(mutantADNFourLines[i])) {

                    numeroDeCoincidencias++;


                }
            }
        }

        return numeroDeCoincidencias;

    }

}
