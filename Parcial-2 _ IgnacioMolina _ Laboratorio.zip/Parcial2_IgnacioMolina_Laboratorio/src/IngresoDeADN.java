import java.util.ArrayList;
import java.util.Scanner;

public class IngresoDeADN {
    private Scanner scanner;
    private ArrayList<String> adnSecuencia;

    public IngresoDeADN(Scanner scanner, ArrayList<String> adnSecuencia) {
        this.scanner = scanner;
        this.adnSecuencia = adnSecuencia;
    }

    public void procesarSecuenciaADN() {

        System.out.println("--------------");
        System.out.println("Ingrese los datos del ADN: ");
        System.out.println("--------------");

        for (int i = 0; i < 6; i++) {
            String[] comprobacionADN = {"A", "T", "G", "C"};

            while (true) {
                System.out.print("Ingrese el valor de 6 posiciones de la fila de la secuencia de ADN " + i + " (Con las letras A, T, G, C): ");
                String ADNValue = scanner.nextLine().toUpperCase();

                if (ADNValue.length() != 6 || !comprobacionADN(ADNValue)) {
                    System.out.println("El valor ingresado no tiene una longitud de 6 posiciones o contiene valores no válidos, vuelve a intentarlo...");
                    continue;
                }

                adnSecuencia.add(ADNValue);
                break;
            }
        }
    }

    public boolean comprobacionADN(String ADNValue) {
        String[] comprobacionADN = {"A", "T", "G", "C"};
        for (int i = 0; i < ADNValue.length(); i++) {
            String letra = String.valueOf(ADNValue.charAt(i));
            if (!inArray(letra, comprobacionADN)) {
                return false;
            }
        }
        return true;
    }

    public boolean inArray(String letra, String[] array) {
        for (String element : array) {
            if (letra.equals(element)) {
                return true;
            }
        }
        return false;
    }
}
