public class esMutante {

    private int numeroDeCombinaciones;

    public esMutante() {
    }

    public esMutante(int numeroDeCombinaciones) {
        this.numeroDeCombinaciones = numeroDeCombinaciones;
    }

    public int getNumeroDeCombinaciones() {
        return numeroDeCombinaciones;
    }

    public void setNumeroDeCombinaciones(int numeroDeCombinaciones) {
        this.numeroDeCombinaciones = numeroDeCombinaciones;
    }

    public boolean isMutant (int numeroDeCombinaciones){

        boolean esMutante = false;

        if (numeroDeCombinaciones > 1) {

            esMutante = true;

        }

        return esMutante;
    }


}
